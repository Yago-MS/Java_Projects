//por YAGO
package act_aplic517;

import java.util.Arrays;

public class Act_aplic517 {

    public static int[] suma(int t[], int numElementos) {
        int[] suma = new int[t.length];
        int total = 0;

        for (int indice = 0; indice < t.length-2; indice++) {
            for (int sumar = indice; sumar < indice + numElementos && sumar <= numElementos + (t.length/2); sumar++) {
                total = total + t[sumar];

            }
            suma[indice] = total;
            total = 0;
        }

        return suma;
    }

    public static void main(String[] args) {
        int[] tabla = new int[]{10, 1, 5, 8, 9, 2};
        int[] sumas = new int[tabla.length];
        int numElementos = 3;
        
        sumas=suma(tabla,numElementos);
        for ( int indice=0;indice<sumas.length;indice++)
        if(sumas[indice]>0)
            System.out.print(sumas[indice] + " ");

    }

}
